<?php

// Start of magickwand v.1.0.9-2

function wandgetexception () {}

function wandgetexceptionstring () {}

function wandgetexceptiontype () {}

function wandhasexception () {}

function isdrawingwand () {}

function ismagickwand () {}

function ispixeliterator () {}

function ispixelwand () {}

function cleardrawingwand () {}

function clonedrawingwand () {}

function destroydrawingwand () {}

function drawaffine () {}

function drawannotation () {}

function drawarc () {}

function drawbezier () {}

function drawcircle () {}

function drawcolor () {}

function drawcomment () {}

function drawcomposite () {}

function drawellipse () {}

function drawgetclippath () {}

function drawgetcliprule () {}

function drawgetclipunits () {}

function drawgetexception () {}

function drawgetexceptionstring () {}

function drawgetexceptiontype () {}

function drawgetfillalpha () {}

function drawgetfillopacity () {}

function drawgetfillcolor () {}

function drawgetfillrule () {}

function drawgetfont () {}

function drawgetfontfamily () {}

function drawgetfontsize () {}

function drawgetfontstretch () {}

function drawgetfontstyle () {}

function drawgetfontweight () {}

function drawgetgravity () {}

function drawgetstrokealpha () {}

function drawgetstrokeopacity () {}

function drawgetstrokeantialias () {}

function drawgetstrokecolor () {}

function drawgetstrokedasharray () {}

function drawgetstrokedashoffset () {}

function drawgetstrokelinecap () {}

function drawgetstrokelinejoin () {}

function drawgetstrokemiterlimit () {}

function drawgetstrokewidth () {}

function drawgettextalignment () {}

function drawgettextantialias () {}

function drawgettextdecoration () {}

function drawgettextencoding () {}

function drawgetvectorgraphics () {}

function drawgettextundercolor () {}

function drawline () {}

function drawmatte () {}

function drawpathclose () {}

function drawpathcurvetoabsolute () {}

function drawpathcurvetorelative () {}

function drawpathcurvetoquadraticbezierabsolute () {}

function drawpathcurvetoquadraticbezierrelative () {}

function drawpathcurvetoquadraticbeziersmoothabsolute () {}

function drawpathcurvetoquadraticbeziersmoothrelative () {}

function drawpathcurvetosmoothabsolute () {}

function drawpathcurvetosmoothrelative () {}

function drawpathellipticarcabsolute () {}

function drawpathellipticarcrelative () {}

function drawpathfinish () {}

function drawpathlinetoabsolute () {}

function drawpathlinetorelative () {}

function drawpathlinetohorizontalabsolute () {}

function drawpathlinetohorizontalrelative () {}

function drawpathlinetoverticalabsolute () {}

function drawpathlinetoverticalrelative () {}

function drawpathmovetoabsolute () {}

function drawpathmovetorelative () {}

function drawpathstart () {}

function drawpoint () {}

function drawpolygon () {}

function drawpolyline () {}

function drawpopclippath () {}

function drawpopdefs () {}

function drawpoppattern () {}

function drawpushclippath () {}

function drawpushdefs () {}

function drawpushpattern () {}

function drawrectangle () {}

function drawrender () {}

function drawrotate () {}

function drawroundrectangle () {}

function drawscale () {}

function drawsetclippath () {}

function drawsetcliprule () {}

function drawsetclipunits () {}

function drawsetfillalpha () {}

function drawsetfillopacity () {}

function drawsetfillcolor () {}

function drawsetfillpatternurl () {}

function drawsetfillrule () {}

function drawsetfont () {}

function drawsetfontfamily () {}

function drawsetfontsize () {}

function drawsetfontstretch () {}

function drawsetfontstyle () {}

function drawsetfontweight () {}

function drawsetgravity () {}

function drawsetstrokealpha () {}

function drawsetstrokeopacity () {}

function drawsetstrokeantialias () {}

function drawsetstrokecolor () {}

function drawsetstrokedasharray () {}

function drawsetstrokedashoffset () {}

function drawsetstrokelinecap () {}

function drawsetstrokelinejoin () {}

function drawsetstrokemiterlimit () {}

function drawsetstrokepatternurl () {}

function drawsetstrokewidth () {}

function drawsettextalignment () {}

function drawsettextantialias () {}

function drawsettextdecoration () {}

function drawsettextencoding () {}

function drawsettextundercolor () {}

function drawsetvectorgraphics () {}

function drawskewx () {}

function drawskewy () {}

function drawtranslate () {}

function drawsetviewbox () {}

function newdrawingwand () {}

function popdrawingwand () {}

function pushdrawingwand () {}

function clearmagickwand () {}

function clonemagickwand () {}

function destroymagickwand () {}

function magickadaptivethresholdimage () {}

function magickaddimage () {}

function magickaddimages () {}

function magickaddnoiseimage () {}

function magickaffinetransformimage () {}

function magickannotateimage () {}

function magickappendimages () {}

function magickaverageimages () {}

function magickblackthresholdimage () {}

function magickblurimage () {}

function magickborderimage () {}

function magickcharcoalimage () {}

function magickchopimage () {}

function magickclipimage () {}

function magickclippathimage () {}

function magickcoalesceimages () {}

function magickcolorfloodfillimage () {}

function magickcolorizeimage () {}

function magickcombineimages () {}

function magickcommentimage () {}

function magickcompareimages () {}

function magickcompositeimage () {}

function magickconstituteimage () {}

function magickcontrastimage () {}

function magickconvolveimage () {}

function magickcropimage () {}

function magickcyclecolormapimage () {}

function magickdeconstructimages () {}

function magickdescribeimage () {}

function magickidentifyimage () {}

function magickdespeckleimage () {}

function magickdisplayimage () {}

function magickdisplayimages () {}

function magickdrawimage () {}

function magickechoimageblob () {}

function magickechoimagesblob () {}

function magickedgeimage () {}

function magickembossimage () {}

function magickenhanceimage () {}

function magickequalizeimage () {}

function magickevaluateimage () {}

function magickflattenimages () {}

function magickflipimage () {}

function magickflopimage () {}

function magickframeimage () {}

function magickfximage () {}

function magickgammaimage () {}

function magickgaussianblurimage () {}

function magickgetcompression () {}

function magickgetcompressionquality () {}

function magickgetcopyright () {}

function magickgetexception () {}

function magickgetexceptionstring () {}

function magickgetexceptiontype () {}

function magickgetfilename () {}

function magickgetformat () {}

function magickgethomeurl () {}

function magickgetimage () {}

function magickgetimagebackgroundcolor () {}

function magickgetimageblob () {}

function magickgetimagesblob () {}

function magickgetimageblueprimary () {}

function magickgetimagebordercolor () {}

function magickgetimagechannelmean () {}

function magickgetimagecolormapcolor () {}

function magickgetimagecolors () {}

function magickgetimagecolorspace () {}

function magickgetimagecompose () {}

function magickgetimagecompression () {}

function magickgetimagecompressionquality () {}

function magickgetimagedelay () {}

function magickgetimagedepth () {}

function magickgetimagedistortion () {}

function magickgetimagedispose () {}

function magickgetimageendian () {}

function magickgetimageattribute () {}

function magickgetimageextrema () {}

function magickgetimagefilename () {}

function magickgetimageformat () {}

function magickgetimagegamma () {}

function magickgetimagegreenprimary () {}

function magickgetimageheight () {}

function magickgetimagehistogram () {}

function magickgetimageindex () {}

function magickgetimageinterlacescheme () {}

function magickgetimageiterations () {}

function magickgetimagemattecolor () {}

function magickgetimagemimetype () {}

function magickgetmimetype () {}

function magickgetimagepage () {}

function magickgetimagepixelcolor () {}

function magickgetimagepixels () {}

function magickgetimageprofile () {}

function magickgetimageproperty () {}

function magickgetimageredprimary () {}

function magickgetimageregion () {}

function magickgetimagerenderingintent () {}

function magickgetimageresolution () {}

function magickgetimagescene () {}

function magickgetimagesignature () {}

function magickgetimagesize () {}

function magickgetimagetickspersecond () {}

function magickgetimagetotalinkdensity () {}

function magickgetimagetype () {}

function magickgetimageunits () {}

function magickgetimagevirtualpixelmethod () {}

function magickgetimagewhitepoint () {}

function magickgetimagewidth () {}

function magickgetinterlacescheme () {}

function magickgetnumberimages () {}

function magickgetoption () {}

function magickgetpackagename () {}

function magickgetpage () {}

function magickgetquantumdepth () {}

function magickgetquantumrange () {}

function magickgetreleasedate () {}

function magickgetresource () {}

function magickgetresourcelimit () {}

function magickgetsamplingfactors () {}

function magickgetsize () {}

function magickgetwandsize () {}

function magickgetversion () {}

function magickgetversionnumber () {}

function magickgetversionstring () {}

function magickhasnextimage () {}

function magickhaspreviousimage () {}

function magickimplodeimage () {}

function magicklabelimage () {}

function magicklevelimage () {}

function magickmagnifyimage () {}

function magickmapimage () {}

function magickmattefloodfillimage () {}

function magickmedianfilterimage () {}

function magickminifyimage () {}

function magickmodulateimage () {}

function magickmontageimage () {}

function magickmorphimages () {}

function magickmosaicimages () {}

function magickmotionblurimage () {}

function magicknegateimage () {}

function magicknewimage () {}

function magicknextimage () {}

function magicknormalizeimage () {}

function magickoilpaintimage () {}

function magickfloodfillpaintimage () {}

function magickopaquepaintimage () {}

function magicktransparentpaintimage () {}

function magickpingimage () {}

function magickposterizeimage () {}

function magickpreviewimages () {}

function magickpreviousimage () {}

function magickprofileimage () {}

function magickquantizeimage () {}

function magickquantizeimages () {}

function magickqueryconfigureoption () {}

function magickqueryconfigureoptions () {}

function magickqueryfontmetrics () {}

function magickgetcharwidth () {}

function magickgetcharheight () {}

function magickgettextascent () {}

function magickgettextdescent () {}

function magickgetstringwidth () {}

function magickgetstringheight () {}

function magickgetmaxtextadvance () {}

function magickqueryfonts () {}

function magickqueryformats () {}

function magickradialblurimage () {}

function magickraiseimage () {}

function magickreadimage () {}

function magickreadimageblob () {}

function magickreadimagefile () {}

function magickreadimages () {}

function magickrecolorimage () {}

function magickreducenoiseimage () {}

function magickremoveimage () {}

function magickremoveimageprofile () {}

function magickremoveimageprofiles () {}

function magickresetimagepage () {}

function magickresetiterator () {}

function magickresampleimage () {}

function magickresizeimage () {}

function magickrollimage () {}

function magickrotateimage () {}

function magicksampleimage () {}

function magickscaleimage () {}

function magickseparateimagechannel () {}

function magicksepiatoneimage () {}

function magicksetbackgroundcolor () {}

function magicksetcompression () {}

function magicksetcompressionquality () {}

function magicksetfilename () {}

function magicksetfirstiterator () {}

function magicksetformat () {}

function magicksetimage () {}

function magicksetimagealphachannel () {}

function magicksetimageattribute () {}

function magicksetimagebackgroundcolor () {}

function magicksetimagebias () {}

function magicksetimageblueprimary () {}

function magicksetimagebordercolor () {}

function magicksetimagecolormapcolor () {}

function magicksetimagecolorspace () {}

function magicksetimagecompose () {}

function magicksetimagecompression () {}

function magicksetimagecompressionquality () {}

function magicksetimagedelay () {}

function magicksetimagedepth () {}

function magicksetimagedispose () {}

function magicksetimageendian () {}

function magicksetimageextent () {}

function magicksetimagesize () {}

function magicksetimagefilename () {}

function magicksetimageformat () {}

function magicksetimagegamma () {}

function magicksetimagegreenprimary () {}

function magicksetimageindex () {}

function magicksetimageinterlacescheme () {}

function magicksetimageiterations () {}

function magicksetimagemattecolor () {}

function magicksetimageoption () {}

function magicksetimagepage () {}

function magicksetimagepixels () {}

function magicksetimageprofile () {}

function magicksetimageproperty () {}

function magicksetimageredprimary () {}

function magicksetimagerenderingintent () {}

function magicksetimageresolution () {}

function magicksetimagescene () {}

function magicksetimagetickspersecond () {}

function magicksetimagetype () {}

function magicksetimageunits () {}

function magicksetimagevirtualpixelmethod () {}

function magicksetimagewhitepoint () {}

function magicksetinterlacescheme () {}

function magicksetlastiterator () {}

function magicksetoption () {}

function magicksetpage () {}

function magicksetpassphrase () {}

function magicksetresolution () {}

function magicksetresourcelimit () {}

function magicksetsamplingfactors () {}

function magicksetsize () {}

function magicksetwandsize () {}

function magicksettype () {}

function magickshadowimage () {}

function magicksharpenimage () {}

function magickshaveimage () {}

function magickshearimage () {}

function magicksolarizeimage () {}

function magickspliceimage () {}

function magickspreadimage () {}

function magickstatisticimage () {}

function magicksteganoimage () {}

function magickstereoimage () {}

function magickstripimage () {}

function magickswirlimage () {}

function magicktextureimage () {}

function magickthresholdimage () {}

function magickthumbnailimage () {}

function magicktintimage () {}

function magicktransformimage () {}

function magicktrimimage () {}

function magickunsharpmaskimage () {}

function magickwaveimage () {}

function magickwhitethresholdimage () {}

function magickwriteimage () {}

function magickwriteimagefile () {}

function magickwriteimages () {}

function newmagickwand () {}

function clearpixeliterator () {}

function destroypixeliterator () {}

function newpixeliterator () {}

function newpixelregioniterator () {}

function pixelgetiteratorexception () {}

function pixelgetiteratorexceptionstring () {}

function pixelgetiteratorexceptiontype () {}

function pixelgetnextiteratorrow () {}

function pixelgetpreviousiteratorrow () {}

function pixelresetiterator () {}

function pixelsetfirstiteratorrow () {}

function pixelsetiteratorrow () {}

function pixelsetlastiteratorrow () {}

function pixelsynciterator () {}

function clearpixelwand () {}

function clonepixelwand () {}

function destroypixelwand () {}

function destroypixelwands () {}

function destroypixelwandarray () {}

function ispixelwandsimilar () {}

function newpixelwand () {}

function newpixelwands () {}

function newpixelwandarray () {}

function pixelgetalpha () {}

function pixelgetalphaquantum () {}

function pixelgetexception () {}

function pixelgetexceptionstring () {}

function pixelgetexceptiontype () {}

function pixelgetblack () {}

function pixelgetblackquantum () {}

function pixelgetblue () {}

function pixelgetbluequantum () {}

function pixelgetcolorasstring () {}

function pixelgetcolorcount () {}

function pixelgetcyan () {}

function pixelgetcyanquantum () {}

function pixelgetgreen () {}

function pixelgetgreenquantum () {}

function pixelgetindex () {}

function pixelgetmagenta () {}

function pixelgetmagentaquantum () {}

function pixelgetopacity () {}

function pixelgetopacityquantum () {}

function pixelgetquantumcolor () {}

function pixelgetred () {}

function pixelgetredquantum () {}

function pixelgetyellow () {}

function pixelgetyellowquantum () {}

function pixelsetalpha () {}

function pixelsetalphaquantum () {}

function pixelsetblack () {}

function pixelsetblackquantum () {}

function pixelsetblue () {}

function pixelsetbluequantum () {}

function pixelsetcolor () {}

function pixelsetcolorcount () {}

function pixelsetcyan () {}

function pixelsetcyanquantum () {}

function pixelsetgreen () {}

function pixelsetgreenquantum () {}

function pixelsetindex () {}

function pixelsetmagenta () {}

function pixelsetmagentaquantum () {}

function pixelsetopacity () {}

function pixelsetopacityquantum () {}

function pixelsetquantumcolor () {}

function pixelsetred () {}

function pixelsetredquantum () {}

function pixelsetyellow () {}

function pixelsetyellowquantum () {}

define ('MW_QuantumRange', 65535);
define ('MW_MaxRGB', 65535);
define ('MW_OpaqueOpacity', 0);
define ('MW_TransparentOpacity', 65535);
define ('MW_UndefinedAlphaChannel', 0);
define ('MW_ActivateAlphaChannel', 1);
define ('MW_DeactivateAlphaChannel', 4);
define ('MW_ResetAlphaChannel', 7);
define ('MW_SetAlphaChannel', 8);
define ('MW_UndefinedAlign', 0);
define ('MW_LeftAlign', 1);
define ('MW_CenterAlign', 2);
define ('MW_RightAlign', 3);
define ('MW_UndefinedChannel', 0);
define ('MW_RedChannel', 1);
define ('MW_CyanChannel', 1);
define ('MW_GreenChannel', 2);
define ('MW_MagentaChannel', 2);
define ('MW_BlueChannel', 4);
define ('MW_YellowChannel', 4);
define ('MW_AlphaChannel', 8);
define ('MW_OpacityChannel', 8);
define ('MW_BlackChannel', 32);
define ('MW_IndexChannel', 32);
define ('MW_AllChannels', 134217727);
define ('MW_UndefinedPathUnits', 0);
define ('MW_UserSpace', 1);
define ('MW_UserSpaceOnUse', 2);
define ('MW_ObjectBoundingBox', 3);
define ('MW_UndefinedColorspace', 0);
define ('MW_RGBColorspace', 1);
define ('MW_GRAYColorspace', 2);
define ('MW_TransparentColorspace', 3);
define ('MW_OHTAColorspace', 4);
define ('MW_LABColorspace', 5);
define ('MW_XYZColorspace', 6);
define ('MW_YCbCrColorspace', 7);
define ('MW_YCCColorspace', 8);
define ('MW_YIQColorspace', 9);
define ('MW_YPbPrColorspace', 10);
define ('MW_YUVColorspace', 11);
define ('MW_CMYKColorspace', 12);
define ('MW_sRGBColorspace', 13);
define ('MW_HSBColorspace', 14);
define ('MW_HSLColorspace', 15);
define ('MW_HWBColorspace', 16);
define ('MW_UndefinedCompositeOp', 0);
define ('MW_NoCompositeOp', 1);
define ('MW_AddCompositeOp', 2);
define ('MW_AtopCompositeOp', 3);
define ('MW_BlendCompositeOp', 4);
define ('MW_BumpmapCompositeOp', 5);
define ('MW_ClearCompositeOp', 7);
define ('MW_ColorBurnCompositeOp', 8);
define ('MW_ColorDodgeCompositeOp', 9);
define ('MW_ColorizeCompositeOp', 10);
define ('MW_CopyBlackCompositeOp', 11);
define ('MW_CopyBlueCompositeOp', 12);
define ('MW_CopyCompositeOp', 13);
define ('MW_CopyCyanCompositeOp', 14);
define ('MW_CopyGreenCompositeOp', 15);
define ('MW_CopyMagentaCompositeOp', 16);
define ('MW_CopyOpacityCompositeOp', 17);
define ('MW_CopyRedCompositeOp', 18);
define ('MW_CopyYellowCompositeOp', 19);
define ('MW_DarkenCompositeOp', 20);
define ('MW_DstAtopCompositeOp', 21);
define ('MW_DstCompositeOp', 22);
define ('MW_DstInCompositeOp', 23);
define ('MW_DstOutCompositeOp', 24);
define ('MW_DstOverCompositeOp', 25);
define ('MW_DifferenceCompositeOp', 26);
define ('MW_DisplaceCompositeOp', 27);
define ('MW_DissolveCompositeOp', 28);
define ('MW_ExclusionCompositeOp', 29);
define ('MW_HardLightCompositeOp', 30);
define ('MW_HueCompositeOp', 31);
define ('MW_InCompositeOp', 32);
define ('MW_LightenCompositeOp', 33);
define ('MW_LuminizeCompositeOp', 35);
define ('MW_MinusCompositeOp', 36);
define ('MW_ModulateCompositeOp', 37);
define ('MW_MultiplyCompositeOp', 38);
define ('MW_OutCompositeOp', 39);
define ('MW_OverCompositeOp', 40);
define ('MW_OverlayCompositeOp', 41);
define ('MW_PlusCompositeOp', 42);
define ('MW_ReplaceCompositeOp', 43);
define ('MW_SaturateCompositeOp', 44);
define ('MW_ScreenCompositeOp', 45);
define ('MW_SoftLightCompositeOp', 46);
define ('MW_SrcAtopCompositeOp', 47);
define ('MW_SrcCompositeOp', 48);
define ('MW_SrcInCompositeOp', 49);
define ('MW_SrcOutCompositeOp', 50);
define ('MW_SrcOverCompositeOp', 51);
define ('MW_SubtractCompositeOp', 52);
define ('MW_ThresholdCompositeOp', 53);
define ('MW_XorCompositeOp', 54);
define ('MW_UndefinedCompression', 0);
define ('MW_NoCompression', 1);
define ('MW_BZipCompression', 2);
define ('MW_FaxCompression', 6);
define ('MW_Group4Compression', 7);
define ('MW_JPEGCompression', 8);
define ('MW_LosslessJPEGCompression', 10);
define ('MW_LZWCompression', 11);
define ('MW_RLECompression', 12);
define ('MW_ZipCompression', 13);
define ('MW_UndefinedDecoration', 0);
define ('MW_NoDecoration', 1);
define ('MW_UnderlineDecoration', 2);
define ('MW_OverlineDecoration', 3);
define ('MW_LineThroughDecoration', 4);
define ('MW_UnrecognizedDispose', 0);
define ('MW_UndefinedDispose', 0);
define ('MW_NoneDispose', 1);
define ('MW_BackgroundDispose', 2);
define ('MW_PreviousDispose', 3);
define ('MW_UndefinedException', 0);
define ('MW_WarningException', 300);
define ('MW_ResourceLimitWarning', 300);
define ('MW_TypeWarning', 305);
define ('MW_OptionWarning', 310);
define ('MW_DelegateWarning', 315);
define ('MW_MissingDelegateWarning', 320);
define ('MW_CorruptImageWarning', 325);
define ('MW_FileOpenWarning', 330);
define ('MW_BlobWarning', 335);
define ('MW_StreamWarning', 340);
define ('MW_CacheWarning', 345);
define ('MW_CoderWarning', 350);
define ('MW_ModuleWarning', 355);
define ('MW_DrawWarning', 360);
define ('MW_ImageWarning', 365);
define ('MW_WandWarning', 370);
define ('MW_MonitorWarning', 385);
define ('MW_RegistryWarning', 390);
define ('MW_ConfigureWarning', 395);
define ('MW_ErrorException', 400);
define ('MW_ResourceLimitError', 400);
define ('MW_TypeError', 405);
define ('MW_OptionError', 410);
define ('MW_DelegateError', 415);
define ('MW_MissingDelegateError', 420);
define ('MW_CorruptImageError', 425);
define ('MW_FileOpenError', 430);
define ('MW_BlobError', 435);
define ('MW_StreamError', 440);
define ('MW_CacheError', 445);
define ('MW_CoderError', 450);
define ('MW_ModuleError', 455);
define ('MW_DrawError', 460);
define ('MW_ImageError', 465);
define ('MW_WandError', 470);
define ('MW_MonitorError', 485);
define ('MW_RegistryError', 490);
define ('MW_ConfigureError', 495);
define ('MW_FatalErrorException', 700);
define ('MW_ResourceLimitFatalError', 700);
define ('MW_TypeFatalError', 705);
define ('MW_OptionFatalError', 710);
define ('MW_DelegateFatalError', 715);
define ('MW_MissingDelegateFatalError', 720);
define ('MW_CorruptImageFatalError', 725);
define ('MW_FileOpenFatalError', 730);
define ('MW_BlobFatalError', 735);
define ('MW_StreamFatalError', 740);
define ('MW_CacheFatalError', 745);
define ('MW_CoderFatalError', 750);
define ('MW_ModuleFatalError', 755);
define ('MW_DrawFatalError', 760);
define ('MW_ImageFatalError', 765);
define ('MW_WandFatalError', 770);
define ('MW_MonitorFatalError', 785);
define ('MW_RegistryFatalError', 790);
define ('MW_ConfigureFatalError', 795);
define ('MW_UndefinedRule', 0);
define ('MW_EvenOddRule', 1);
define ('MW_NonZeroRule', 2);
define ('MW_UndefinedFilter', 0);
define ('MW_PointFilter', 1);
define ('MW_BoxFilter', 2);
define ('MW_TriangleFilter', 3);
define ('MW_HermiteFilter', 4);
define ('MW_HanningFilter', 5);
define ('MW_HammingFilter', 6);
define ('MW_BlackmanFilter', 7);
define ('MW_GaussianFilter', 8);
define ('MW_QuadraticFilter', 9);
define ('MW_CubicFilter', 10);
define ('MW_CatromFilter', 11);
define ('MW_MitchellFilter', 12);
define ('MW_LanczosFilter', 22);
define ('MW_BesselFilter', 13);
define ('MW_SincFilter', 14);
define ('MW_UndefinedGravity', 0);
define ('MW_ForgetGravity', 0);
define ('MW_NorthWestGravity', 1);
define ('MW_NorthGravity', 2);
define ('MW_NorthEastGravity', 3);
define ('MW_WestGravity', 4);
define ('MW_CenterGravity', 5);
define ('MW_EastGravity', 6);
define ('MW_SouthWestGravity', 7);
define ('MW_SouthGravity', 8);
define ('MW_SouthEastGravity', 9);
define ('MW_StaticGravity', 10);
define ('MW_UndefinedType', 0);
define ('MW_BilevelType', 1);
define ('MW_GrayscaleType', 2);
define ('MW_GrayscaleMatteType', 3);
define ('MW_PaletteType', 4);
define ('MW_PaletteMatteType', 5);
define ('MW_TrueColorType', 6);
define ('MW_TrueColorMatteType', 7);
define ('MW_ColorSeparationType', 8);
define ('MW_ColorSeparationMatteType', 9);
define ('MW_OptimizeType', 10);
define ('MW_UndefinedInterlace', 0);
define ('MW_NoInterlace', 1);
define ('MW_LineInterlace', 2);
define ('MW_PlaneInterlace', 3);
define ('MW_PartitionInterlace', 4);
define ('MW_UndefinedCap', 0);
define ('MW_ButtCap', 1);
define ('MW_RoundCap', 2);
define ('MW_SquareCap', 3);
define ('MW_UndefinedJoin', 0);
define ('MW_MiterJoin', 1);
define ('MW_RoundJoin', 2);
define ('MW_BevelJoin', 3);
define ('MW_UndefinedEvaluateOperator', 0);
define ('MW_AddEvaluateOperator', 1);
define ('MW_AndEvaluateOperator', 2);
define ('MW_DivideEvaluateOperator', 3);
define ('MW_LeftShiftEvaluateOperator', 4);
define ('MW_MaxEvaluateOperator', 5);
define ('MW_MinEvaluateOperator', 6);
define ('MW_MultiplyEvaluateOperator', 7);
define ('MW_OrEvaluateOperator', 8);
define ('MW_RightShiftEvaluateOperator', 9);
define ('MW_SetEvaluateOperator', 10);
define ('MW_SubtractEvaluateOperator', 11);
define ('MW_XorEvaluateOperator', 12);
define ('MW_UndefinedMetric', 0);
define ('MW_MeanAbsoluteErrorMetric', 2);
define ('MW_MeanSquaredErrorMetric', 4);
define ('MW_PeakAbsoluteErrorMetric', 5);
define ('MW_PeakSignalToNoiseRatioMetric', 6);
define ('MW_RootMeanSquaredErrorMetric', 7);
define ('MW_UndefinedMode', 0);
define ('MW_FrameMode', 1);
define ('MW_UnframeMode', 2);
define ('MW_ConcatenateMode', 3);
define ('MW_UndefinedNoise', 0);
define ('MW_UniformNoise', 1);
define ('MW_GaussianNoise', 2);
define ('MW_MultiplicativeGaussianNoise', 3);
define ('MW_ImpulseNoise', 4);
define ('MW_LaplacianNoise', 5);
define ('MW_PoissonNoise', 6);
define ('MW_UndefinedMethod', 0);
define ('MW_PointMethod', 1);
define ('MW_ReplaceMethod', 2);
define ('MW_FloodfillMethod', 3);
define ('MW_FillToBorderMethod', 4);
define ('MW_ResetMethod', 5);
define ('MW_UndefinedPreview', 0);
define ('MW_RotatePreview', 1);
define ('MW_ShearPreview', 2);
define ('MW_RollPreview', 3);
define ('MW_HuePreview', 4);
define ('MW_SaturationPreview', 5);
define ('MW_BrightnessPreview', 6);
define ('MW_GammaPreview', 7);
define ('MW_SpiffPreview', 8);
define ('MW_DullPreview', 9);
define ('MW_GrayscalePreview', 10);
define ('MW_QuantizePreview', 11);
define ('MW_DespecklePreview', 12);
define ('MW_ReduceNoisePreview', 13);
define ('MW_AddNoisePreview', 14);
define ('MW_SharpenPreview', 15);
define ('MW_BlurPreview', 16);
define ('MW_ThresholdPreview', 17);
define ('MW_EdgeDetectPreview', 18);
define ('MW_SpreadPreview', 19);
define ('MW_SolarizePreview', 20);
define ('MW_ShadePreview', 21);
define ('MW_RaisePreview', 22);
define ('MW_SegmentPreview', 23);
define ('MW_SwirlPreview', 24);
define ('MW_ImplodePreview', 25);
define ('MW_WavePreview', 26);
define ('MW_OilPaintPreview', 27);
define ('MW_CharcoalDrawingPreview', 28);
define ('MW_JPEGPreview', 29);
define ('MW_UndefinedIntent', 0);
define ('MW_SaturationIntent', 1);
define ('MW_PerceptualIntent', 2);
define ('MW_AbsoluteIntent', 3);
define ('MW_RelativeIntent', 4);
define ('MW_UndefinedResolution', 0);
define ('MW_PixelsPerInchResolution', 1);
define ('MW_PixelsPerCentimeterResolution', 2);
define ('MW_UndefinedResource', 0);
define ('MW_AreaResource', 1);
define ('MW_DiskResource', 2);
define ('MW_FileResource', 3);
define ('MW_MapResource', 4);
define ('MW_MemoryResource', 5);
define ('MW_UndefinedStatistic', 0);
define ('MW_GradientStatistic', 1);
define ('MW_MaximumStatistic', 2);
define ('MW_MeanStatistic', 3);
define ('MW_MedianStatistic', 4);
define ('MW_MinimumStatistic', 5);
define ('MW_ModeStatistic', 6);
define ('MW_NonpeakStatistic', 7);
define ('MW_StandardDeviationStatistic', 8);
define ('MW_UndefinedPixel', 0);
define ('MW_CharPixel', 1);
define ('MW_ShortPixel', 7);
define ('MW_IntegerPixel', 4);
define ('MW_LongPixel', 5);
define ('MW_FloatPixel', 3);
define ('MW_DoublePixel', 2);
define ('MW_UndefinedStretch', 0);
define ('MW_NormalStretch', 1);
define ('MW_UltraCondensedStretch', 2);
define ('MW_ExtraCondensedStretch', 3);
define ('MW_CondensedStretch', 4);
define ('MW_SemiCondensedStretch', 5);
define ('MW_SemiExpandedStretch', 6);
define ('MW_ExpandedStretch', 7);
define ('MW_ExtraExpandedStretch', 8);
define ('MW_UltraExpandedStretch', 9);
define ('MW_AnyStretch', 10);
define ('MW_UndefinedStyle', 0);
define ('MW_NormalStyle', 1);
define ('MW_ItalicStyle', 2);
define ('MW_ObliqueStyle', 3);
define ('MW_AnyStyle', 4);
define ('MW_UndefinedVirtualPixelMethod', 0);
define ('MW_ConstantVirtualPixelMethod', 2);
define ('MW_EdgeVirtualPixelMethod', 4);
define ('MW_MirrorVirtualPixelMethod', 5);
define ('MW_TileVirtualPixelMethod', 7);

// End of magickwand v.1.0.9-2
