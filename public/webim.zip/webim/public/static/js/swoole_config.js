var junim = {
	'server' : 'ws://im.swoole.com:9501',
};