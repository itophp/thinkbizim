<?php
// 定义应用目录
define('APP_PATH', __DIR__ . '/../application/');
define('BIND_MODULE','swoole/WebSocket');
// 加载框架引导文件
require __DIR__ . '/../thinkphp/start.php';