<?php
namespace app\index\controller;

use think\Controller;
use app\common\controller\Homebase;
use think\Request;
use think\Db;

class Login extends Homebase
{
	//set model
	protected $model;
	//set _initialie
	public function _initialize()
	{
		parent::_initialize();
		$domain = Request::instance()->domain();
		if( $domain == 'http://im.swoole.com' ){
			//model name
			$this->model = Db::name('user');
		}else{
			//return error
			$error_data = 'Illegal operation!!';
			return $this->error($error_data,'index/index');
		}
		//halt(session('user'));
		//check user login status
		if( !empty(session('user.id')) ){
			//return redirect
			session('user',null);
			//$this->redirect('index/index');
		}
	}

	/**
	 * login method
	 * @return mixed
	 */
	public function index()
	{
		//phpinfo();die;
		return $this->fetch();		
	}

	/**
	 * dologin method
	 * @param post
	 * @return mixed
	 */
	public function dologin(Request $request)
	{

		
		//get param 
		//login_account
		$loginAccount = trim(input('login_account'));
		if( empty($loginAccount) ){
			$errorData = 'Pleace entry your login account!!'; 
			return $this->error($errorData);
		};
		//login_pass
		$loginPass = input('pass');
		//encrypt password
		$loginPass = encrypt_pwd($loginPass);
		//check user
		$field = 'id,nickname,email,mobile,avatar,token,status';
		$user = $this->model->where('passwd',$loginPass)->where('email',$loginAccount)->whereOr('mobile',$loginAccount)->whereOr('nickname',$loginAccount)->find();
		if( !empty( $user['id'] )) {

			//check user lock status
			if( $user['status'] == 2 ){
				$errorData = 'Your account is locking!!';
				return $this->error( $errorData );
			}
			//update token
			$user['token'] = create_token();
			$updateToken = $this->model->where('id',$user['id'])->update(['token'=>$user['token']]);
			//halt($updateToken);
			if($updateToken == false){ 
				$errorData = 'Login failed: token created failed!!!';
				return $this->error($errorData);
			}
			//create redis data
			// $redis  = new \Redis();
			
			// if(!$redis->connect('127.0.0.1',6379)){
			// 	$errorData = 'Redis connect failed!!!';
			// 	return $this->error( $errorData );
			// }
			// $redis->delete('online-'.$user['id']);
			// $redis->sadd('online-'.$user['id'],'nickname:'.$user['nickname']);
			// $redis->sadd('online-'.$user['id'],'emali:'.$user['email']);
			// $redis->sadd('online-'.$user['id'],'mobile:'.$user['mobile']);
			// $redis->sadd('online-'.$user['id'],'avatar:'.$user['avatar']);
			// $redis->sadd('online-'.$user['id'],'token:'.$user['token']);
			// $redis->sadd('online-'.$user['id'],'status:'.$user['status']);

			//create session
			$encryptUser['id'] = $user['id'];
			$encryptUser['user'] = $user['nickname'];
			$encryptUser['token'] = $user['token'];
			$secretToken = base_encrypt($encryptUser,'user');
			//ini_set("session.save_handler", "redis");
			//ini_set("session.save_path", "tcp://127.0.0.1:6379");
			//halt(session_save_path());
			session('user',$user);
			session('secretToken',$secretToken);
			$successData = 'Login success!!';
			return $this->success($successData,'chat/index');
		} else {
			$errorData = 'Your account don\'t exist,or your password is wrong!!!';
			return $this->error( $errorData );
		}
	}


	/**
	 * register method
	 * @param POST
	 * @return redirect
	 */
	public function register(Request $request)
	{
		//check post data
		$this->isPost($request);
		//set postData
		$postData = input();
		//check pass and repass
		if( $postData['pass'] !== $postData['repass'] ){
			//return repass error
			$errorData = 'Two passwords are inconsistent!!!';
			return $this->error($errorData);
		}
		//set insert data
		$insert = array();
		//user registration mode : email or mobile
		if( $postData['email'] ){
			$insertData['email'] = $postData['email'] ?? '';
		}elseif( $postData['mobile'] ){
			$insertData['mobile'] = $postData['mobile'] ?? '';
		}else{
			//return error
			$errorData = 'Your registration mode is wrong!!!';
			return $this->error( $errorData ,'index/index');
		}
		$insertData['nickname'] = $postData['nickname'] ?? '';
		$insertData['passwd'] = $postData['pass'] ?? '';
		$insertData['passwd'] = encrypt_pwd($insertData['passwd']);
		$insertData['status'] = '1';
		//validate insertData
		$validate = $this->validate($insertData,'User');
		if( $validate !== true ){
			//return error
			return $this->error($validate, 'index/index');
		}
		//insert user data
		$insertId = $this->model->insertGetId($insertData);
		if( $insert !== false ){
			//return success info
			$errorData = 'Registration is successful!!&nbsp;&nbsp;3 seconds after the jump to the login page';
			return $this->success($errorData,'login/index');
		}else{
			//return error info
			$errorData = 'Registration failed!!&nbsp;&nbsp;3 seconds after the jump to the register page';
			return $this->error($errorData);
		}	
	}
}