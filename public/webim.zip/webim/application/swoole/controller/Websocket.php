<?php
namespace app\swoole\controller;

use think\Controller;
use think\Db;

/**
* 
*/
class Websocket extends Controller
{
	/**
	 * WebSocket param
	 */
	//WebSocket host
	protected $host = '0.0.0.0';
	//WebSocket port
	protected $port = 9501;

	protected $serv;
	protected $redis;
	protected $users;
	/**
	 * Connection websocket
	 * event callback
	 *
	 */
	public function index()
	{

		//instantiation WebSocket server
		$this->serv = new \swoole_websocket_server($this->host,$this->port);
		//listening connect event
		$this->serv->on('open',array($this,'onOpen'));
		//listening message event
		$this->serv->on('message',array($this,'onMessage'));
		//listening close event
		$this->serv->on('close',array($this,'onClose'));
		//WebSocket server start
		$this->serv->start();
	}

	/**
	 * 
	 * 
	 */
	public function onOpen($ws,$request)
	{
		//set callback data
		$msg['cmd'] = 'login';
		$msg['fd'] = $request->fd;
		$msg = json_encode($msg);
		$ws->push($request->fd,$msg);
	}

	/**
	 *
	 */
	public function onMessage($ws,$frame)
	{
		$data = json_decode($frame->data);

		//cmd
		switch ( $data->cmd ) {
			case 'login':
				$this->onLogin($frame);
				break;
			case 'getHistory':
			 	$this->onGetHistory();
			 	break;
			case 'getOnline':
				$this->onGetOnline();
				break;
			case 'message':
				$this->onNewMessage($ws,$frame);
				break;
		}
	}

	public function onClose($ws,$fd)
	{
		$redis = new \Redis();
		//connect redis
		$redis->connect('127.0.0.1',6379);
		$userId = $redis->get('online-'.$fd.'-uid');
		$redis->delete('online-'.$fd.'-uid');
		$redis->delete('online-'.$userId.'-fd');
		$sendData['cmd'] = 'offLine';
		$sendData['from_id'] = $userId;
		$sendData['msg'] = 'Your friend:'.$this->users[$userId]['nickname'].' is off the line!!';
		$this->sendToOnlineFriend($userId,$sendData);
		echo $fd.'off-line';

	}

	public function onLogin($frame)
	{
		echo $frame->fd.' :login';
		$data = json_decode($frame->data);
		//decrypt secretToken;
		$secretTokenArr = base_decrypt( $data->secretToken );
		//json_decode $secretTokenArr['data'];
		$secretTokenData = json_decode( $secretTokenArr['data'] );
		//get redis data
		//connect redis
		$this->redis = new \Redis();
		//connect redis
		if( $this->redis->connect('127.0.0.1',6379) ){
			//get session data
			$sessionData = $this->redis->get('PHPREDIS_SESSION:' . $data->sessid);
			//explode $sessionData
			$sessData = explode( '|', $sessionData );
			$sessData = unserialize( $sessData[1] );
			//check data
			if( $sessData['user']['token'] !== $secretTokenData->token ){
				$errorData['cmd'] = 'error';
				$errorData['error_code'] = 14011;
				$errorData['error_data'] = 'Illegal operation!!!';
				$ws->push( $frame->fd,json_encode( $errorData ) );
			}
			if( empty($sessData['user']) ){
				//set error code and data
				$errorData['cmd'] = 'error';
				$errorData['error_code'] = 14001;
				$errorData['error_data'] = 'You are not logged in!!!';
				$ws->push( $frame->fd,json_encode( $errorData ) );
			}
			$userData = $sessData['user'];
			//bind fd -- user_id
			$this->redis->delete('online-'.$userData['id'].'-fd');
			$this->redis->delete('online-'.$frame->fd.'-uid');
			$this->redis->set('online-'.$userData['id'].'-fd',$frame->fd);
			$this->redis->set('online-'.$frame->fd.'-uid',$userData['id']);
			//save user info
			$this->users[$userData['id']] = $userData;
			//send
			$sendData['cmd'] = 'newUser';
			$sendData['from_id'] = $userData['id'];
			$sendData['msg'] = 'Your friend:'.$this->users[$userData['id']]['nickname'].' is on the line!!';
			$this->sendToOnlineFriend($userData['id'],$sendData);
		}else{
			$errorData['cmd'] = 'error';
			$errorData['error_code'] = 14002;
			$errorData['error_data'] = 'Redis connection failed!!!';
			$ws->push( $frame->fd,json_encode( $errorData ) );
		}
	}

	/**
	 * 
	 *
	 */
	public function onNewMessage($ws,$frame)
	{
		//$sendData['cmd'] = 

	}



	/**
	 * send json data to friend
	 */
	public function sendToOnlineFriend($userId,$data)
	{
		//get all friend
		$friendArr = Db::name('friends')->where(['user_id'=>$userId,'status'=>1])->column('friend_id');
		
		//find fd or redis
		foreach ( $friendArr as $id ) {
			//get fd
			$client_id = $this->redis->get('online-'.$id.'-fd');
			if( !empty($client_id) ){
				
				$client_id = $client_id[0];
				//send data
				$jsonData = json_encode($data,true);
				if( $this->serv->push($client_id,$jsonData) === false)
				{
					$this->serv->close($this->serv,$client_id);
					echo 'send failed!!';
				}
				echo 'send success!!';
			}else{
				
				continue;
			}
		}
	}

	/**
	 * 
	 */
	public function sendToFriend($userId,$data)
	{
		//

	}

}